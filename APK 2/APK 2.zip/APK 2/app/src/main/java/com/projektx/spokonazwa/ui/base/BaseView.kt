package com.projektx.spokonazwa.ui.base


interface BaseView {
    fun showError(error : String)
}
