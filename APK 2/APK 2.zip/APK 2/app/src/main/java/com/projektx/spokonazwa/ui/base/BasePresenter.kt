package com.projektx.spokonazwa.ui.base

interface BasePresenter {
    fun init()
    fun dispose()
}
