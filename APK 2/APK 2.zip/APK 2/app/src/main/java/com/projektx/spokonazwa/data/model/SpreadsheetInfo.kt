package com.projektx.spokonazwa.data.model


data class SpreadsheetInfo(val id : String, val url : String)