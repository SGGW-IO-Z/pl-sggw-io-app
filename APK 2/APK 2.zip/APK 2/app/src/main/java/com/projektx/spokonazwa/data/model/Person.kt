package com.projektx.spokonazwa.data.model


data class Person(val name : String, val major : String)